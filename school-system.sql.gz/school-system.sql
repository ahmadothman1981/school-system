-- Adminer 4.8.1 MySQL 5.5.5-10.6.16-MariaDB-0ubuntu0.22.04.1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admins` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1,	'ahmad',	'ahmad@yahoo.com',	NULL,	'$2y$12$8i92kzqNg3SWRpKR.PcFB.b14xTbAEnSlXHRyhAE.i0EBOJytr/7y',	NULL,	'2024-02-12 17:02:20',	'2024-02-12 17:02:20');

DROP TABLE IF EXISTS `classes`;
CREATE TABLE `classes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `classes` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1,	'KG1',	'2024-02-13 04:55:23',	'2024-02-14 04:51:03'),
(2,	'KG2',	'2024-02-13 05:01:54',	'2024-02-13 05:01:54'),
(3,	'ما قبل المرحلة الابتدائية',	'2024-02-13 05:03:00',	'2024-02-13 05:03:00'),
(4,	'كورس برمجة',	'2024-02-13 05:03:09',	'2024-02-13 05:03:09'),
(5,	'كورس دفاع عن النفس',	'2024-02-13 05:03:28',	'2024-02-13 05:03:28'),
(6,	'تأسيس لغة عربية',	'2024-02-13 05:03:39',	'2024-02-13 05:03:39'),
(7,	'تأسيس لغة انجليزية',	'2024-02-13 05:03:55',	'2024-02-13 05:03:55'),
(14,	'القرأن والحديث',	'2024-02-14 04:32:49',	'2024-02-14 04:32:49');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(20,	'2014_10_12_000000_create_users_table',	1),
(21,	'2014_10_12_100000_create_password_reset_tokens_table',	1),
(22,	'2019_08_19_000000_create_failed_jobs_table',	1),
(23,	'2019_12_14_000001_create_personal_access_tokens_table',	1),
(24,	'2024_01_27_101032_create_admins_table',	1),
(25,	'2024_02_10_062057_add_column_to_table',	1),
(26,	'2024_02_12_055846_create_classes_table',	1),
(27,	'2024_02_12_064010_create_teachers_table',	1);

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `teachers`;
CREATE TABLE `teachers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `teachers` (`id`, `name`, `email`, `phone`, `created_at`, `updated_at`) VALUES
(1,	'داليا عثمان شعيب الدسوقى',	'othman@mail.com',	'01113736196',	'2024-02-13 09:14:00',	'2024-02-13 09:14:00'),
(2,	'احمد عثمان شهيب الدسوقى',	'ahmad@mail.com',	'01113736196',	'2024-02-13 11:16:01',	'2024-02-13 11:16:01');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `phone` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `class` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `phone`, `date_of_birth`, `photo`, `address`, `notes`, `class`) VALUES
(1,	'aisha',	'aisha@mail.com',	NULL,	'$2y$12$Uwy3j2VTh5VR/4tdOcXwseJmvcSqiZrXI/Qgrh8WmTvmneHBsJgfO',	NULL,	'2024-02-12 10:36:48',	'2024-02-12 10:36:48',	'0123456789',	'2020-10-25',	NULL,	'sherbeen',	NULL,	NULL),
(2,	'othman ahmad othman',	'othman@mail.com',	NULL,	'$2y$12$UhIy7ukN89sMzM.QgdBL.elcXqk6ANuSEu9x3PENzTAIisZ7L6.Iy',	NULL,	'2024-02-13 11:45:18',	'2024-02-13 11:45:18',	'01113736196',	'2020-06-25',	NULL,	'sherbeen',	NULL,	NULL);

-- 2024-02-14 07:06:10
